-- 1. Display the first_name, last_name, and email 
--    for all the users in the "users" table
--    sort by last_name descending


-- 2. Count all of the users in the users table



-- 3. Display the first_name, last_name, and email 
--    for all the users whose first name is Kristy


-- 4. Display the id, first_name, last_name, and email 
--    for users whose ids are either 2, 5, 7, 9, 11, or 23.


-- 5. Display the first_name, last_name, and email 
--    for all the users whose use gmail for email.


-- 6. Write a query that joins the posts and users table. The results
-- should display the id and pub_date from the posts table, and 
-- the author's username, first_name, and last_name from the users table



-- 7. Display all of the usernames that user id=5 is following.
--    You'll need to join the users table to the following table.