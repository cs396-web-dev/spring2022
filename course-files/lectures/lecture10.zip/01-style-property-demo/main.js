
const makeRed = (ev) => {
    alert('set background to orange');
};

const makeBlue = (ev) => {
    alert('set background to orange');
};

const makePink = (ev) => {
    alert('set background to orange');
};

const makeOrange = (ev) => {
    alert('set background to orange');
};


document.querySelector('#btn1').addEventListener('click', makeRed);
document.querySelector('#btn2').addEventListener('click', makeBlue);
document.querySelector('#btn3').addEventListener('click', makePink);
document.querySelector('#btn4').addEventListener('click', makeOrange);