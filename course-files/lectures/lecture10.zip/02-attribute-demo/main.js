const showCat = (ev) => {
    alert('cat functionality');
};

const showDog = (ev) => {
    alert('dog functionality');
};

const showBird = (ev) => {
    alert('bird functionality');
};

const showFish = (ev) => {
    alert('fish functionality');
};
