const makeBigger = () => {
   alert('make bigger!');
};

const makeSmaller = () => {
   alert('make smaller!');
};

/*
document.querySelector(???).addEventListener('click', makeBigger);
document.querySelector(???).addEventListener('click', makeSmaller);
*/
